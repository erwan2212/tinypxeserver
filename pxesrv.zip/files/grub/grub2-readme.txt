download grub-2.02-for-windows.zip here ftp://ftp.gnu.org/gnu/grub/
or
download grub-2.0.5 from here https://github.com/aIive/builds

-place i386-pc and x86_64-efi folders in this grub folder
-place grub-mkimage.exe file in this grub folder
